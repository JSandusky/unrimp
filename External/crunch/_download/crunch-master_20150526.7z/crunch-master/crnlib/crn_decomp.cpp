// File: crn_decomp.cpp
// See Copyright Notice and license at the end of inc/crnlib.h
#include "crn_core.h"

// Include the single-file header library with no defines, which brings in the full CRN decompressor.
#include "../inc/crn_decomp.h"
