
extern "C" {
#include "hlslcc.h"
}

