#ifndef SERIALIZE_REFLECTION_H_
#define SERIALIZE_REFLECTION_H_

#include "hlslcc.h"

const char* SerializeReflection(ShaderInfo* psReflection);

#endif
